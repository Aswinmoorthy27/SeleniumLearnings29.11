package com.commonutils;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class base {

	public String excelFileName;
	public String sheetName;

	@DataProvider
	public String[][] senddata() throws IOException {
		return Excel.excelmethod(excelFileName, sheetName);
	}
}
