package definitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;

public class Logindefinitions {

	public WebDriver driver;
	WebElement loginbt;

	@Given("User is on login page")
	public void user_is_on_login_page() {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\aswin.moorthy\\Automation\\DemoHRMS\\drivers\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://practicetestautomation.com/practice-test-login/");

	}

	@Then("User enter {string}")
	public void user_enter_uname1(String uname) {
		driver.findElement(By.id("username")).sendKeys(uname);
	}

	@Then("User is enter {string}")
	public void user_is_enter(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);

	}

	@Then("User Click on Login button")
	public void user_click_on_login_button() throws InterruptedException {
		Thread.sleep(5000);
		loginbt = driver.findElement(By.id("submit"));
		loginbt.click();

	}

	@Then("Verify login successfull")
	public void verify_login_successfull() throws InterruptedException {
		Thread.sleep(15000);

		String Title = driver.getTitle();
		Assert.assertEquals("Logged In Successfully | Practice Test Automation", Title);

	}

	@Then("user should loged out")
	public void user_should_loged_out() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Log out']")).click();
        driver.close();
	}

}
